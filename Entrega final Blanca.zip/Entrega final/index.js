const formulario = document.getElementById('form');
const inputs = document.querySelectorAll('#form input');

const expresiones = {
	nombre: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
	clave: /^.{4,12}$/, // 4 a 12 digitos.
	email: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
	telefono: /^\d{7,14}$/ // 7 a 14 numeros.
}

const campos = {
    nombre: false,
    email: false,
    clave: false,
    confirm: false
}

const validarFormulario = (e) => {
    switch (e.target.name){
        case "nombre":
            validarCampo(expresiones.nombre, e.target, 'nombre')
        break;

        case "email":
            validarCampo2(expresiones.email, e.target, 'email')
        break;

        case "clave":
            validarCampo3(expresiones.clave, e.target, 'clave')
            validarPassword2();
        break;

        case "confirm":
           validarPassword2_2();
        break;
    }
}

const validarCampo = (expresion, input, campo) => {
    if(expresion.test(input.value)){
        document.getElementById(`grupo__${campo}`).classList.remove('form__grupo-incorrecto')
        document.getElementById(`grupo__${campo}`).classList.add('form__grupo-correcto')
        document.querySelector(`#grupo__${campo} .form__input-error`).classList.remove('form__input-error-activo');

        campos[campo] = true;
				document.getElementById('imagen').src = 'images/success-icon.svg';

       keypress();
    } else {
        document.getElementById(`grupo__${campo}`).classList.remove('form__grupo-correcto')
        document.getElementById(`grupo__${campo}`).classList.add('form__grupo-incorrecto')
        document.querySelector(`#grupo__${campo} .form__input-error`).classList.add('form__input-error-activo');

				document.getElementById('imagen').src = 'images/error-icon.svg';

        campos[campo] = false;
    }
}
const validarCampo2 = (expresion, input, campo) => {
    if(expresion.test(input.value)){
        document.getElementById(`grupo__${campo}`).classList.remove('form__grupo-incorrecto')
        document.getElementById(`grupo__${campo}`).classList.add('form__grupo-correcto')
        document.querySelector(`#grupo__${campo} .form__input-error`).classList.remove('form__input-error-activo');

        campos[campo] = true;

				document.getElementById('imagen2').src = 'images/success-icon.svg';
       keypress();
    } else {
        document.getElementById(`grupo__${campo}`).classList.remove('form__grupo-correcto')
        document.getElementById(`grupo__${campo}`).classList.add('form__grupo-incorrecto')
        document.querySelector(`#grupo__${campo} .form__input-error`).classList.add('form__input-error-activo');


				document.getElementById('imagen2').src = 'images/error-icon.svg';
        campos[campo] = false;
    }
}
const validarCampo3 = (expresion, input, campo) => {
    if(expresion.test(input.value)){
        document.getElementById(`grupo__${campo}`).classList.remove('form__grupo-incorrecto')
        document.getElementById(`grupo__${campo}`).classList.add('form__grupo-correcto')
        document.querySelector(`#grupo__${campo} .form__input-error`).classList.remove('form__input-error-activo');

        campos[campo] = true;

				document.getElementById('imagen3').src = 'images/success-icon.svg';
       keypress();
    } else {
        document.getElementById(`grupo__${campo}`).classList.remove('form__grupo-correcto')
        document.getElementById(`grupo__${campo}`).classList.add('form__grupo-incorrecto')
        document.querySelector(`#grupo__${campo} .form__input-error`).classList.add('form__input-error-activo');


				document.getElementById('imagen3').src = 'images/error-icon.svg';
        campos[campo] = false;
    }
}
const validarPassword2 = () => {
    const inputPassword1 = document.getElementById('clave');
    const inputPassword2 = document.getElementById('confirm');

    if(inputPassword1.value !== inputPassword2.value){
        document.getElementById('grupo__confirm').classList.remove('form__grupo-correcto')
        document.getElementById('grupo__confirm').classList.add('form__grupo-incorrecto')
        document.querySelector('#grupo__confirm .form__input-error-confirm-password').classList.add('form__input-error-confirm-password-activo');
				document.getElementById('imagen4').src = 'images/error-icon.svg';

        campos['clave'] = false;
    } else {
        document.getElementById('grupo__confirm').classList.remove('form__grupo-incorrecto')
        document.getElementById('grupo__confirm').classList.add('form__grupo-correcto')
        document.querySelector('#grupo__confirm .form__input-error-confirm-password').classList.remove('form__input-error-confirm-password-activo');
				document.getElementById('imagen4').src = 'images/success-icon.svg';

        campos['clave'] = true;
    }
}
const validarPassword2_2 = () => {
    const inputPassword1 = document.getElementById('clave');
    const inputPassword2 = document.getElementById('confirm');

    if(inputPassword1.value !== inputPassword2.value){
        document.getElementById('grupo__confirm').classList.remove('form__grupo-correcto')
        document.getElementById('grupo__confirm').classList.add('form__grupo-incorrecto')
        document.querySelector('#grupo__confirm .form__input-error-confirm-password').classList.add('form__input-error-confirm-password-activo');

				document.getElementById('imagen4').src = 'images/error-icon.svg';
        campos['clave'] = false;
    } else {
        document.getElementById('grupo__confirm').classList.remove('form__grupo-incorrecto')
        document.getElementById('grupo__confirm').classList.add('form__grupo-correcto')
        document.querySelector('#grupo__confirm .form__input-error-confirm-password').classList.remove('form__input-error-confirm-password-activo');

				document.getElementById('imagen4').src = 'images/success-icon.svg';
        campos['clave'] = true;
    }
}


inputs.forEach((input) => {
    input.addEventListener('keyup', validarFormulario);
    input.addEventListener('blur', validarFormulario);
});

formulario.addEventListener('submit', (e) => {
    e.preventDefault();

    if(campos.nombre && campos.email && campos.clave) {
        formulario.reset();
        window.alert("Inscripción enviada correctamente");
        document.getElementById('grupo__nombre').classList.remove('form__grupo-correcto');
        document.getElementById('grupo__email').classList.remove('form__grupo-correcto');
        document.getElementById('grupo__clave').classList.remove('form__grupo-correcto');
        document.getElementById('grupo__confirm').classList.remove('form__grupo-correcto');
				document.getElementById('imagen').remove();
				document.getElementById('imagen2').remove();
				document.getElementById('imagen3').remove();
				document.getElementById('imagen4').remove();

    }
})


function click1(){

    nombre = document.getElementById('nombre').value;
    email = document.getElementById('email').value;
    clave = document.getElementById('clave').value;
    confirma = document.getElementById('confirm').value;


    if (nombre == ""){
        document.getElementById(`grupo__nombre`).classList.add('form__grupo-incorrecto')
        document.querySelector(`#grupo__nombre .form__input-vacio`).classList.add('form__input-vacio-activo')
        document.getElementById('imagen').src = 'images/error-icon.svg';
        
      }
    if (email == ""){
        document.getElementById(`grupo__email`).classList.add('form__grupo-incorrecto')
        document.querySelector(`#grupo__email .form__input-vacio`).classList.add('form__input-vacio-activo')
        document.getElementById('imagen2').src = 'images/error-icon.svg';
     }
    if (clave == ""){
        document.getElementById(`grupo__clave`).classList.add('form__grupo-incorrecto')
        document.querySelector(`#grupo__clave .form__input-vacio`).classList.add('form__input-vacio-activo')
        document.getElementById('imagen3').src = 'images/error-icon.svg';
    }
    if (confirma == ""){
        document.getElementById(`grupo__confirm`).classList.add('form__grupo-incorrecto')
        document.querySelector(`#grupo__confirm .form__input-vacio`).classList.add('form__input-vacio-activo');
        document.getElementById('imagen4').src = 'images/error-icon.svg';
    }

}

function keypress(){

    nombre2 = document.getElementById('nombre').value;
    email2 = document.getElementById('email').value;
    clave2 = document.getElementById('clave').value;
    confirma2 = document.getElementById('confirm').value;

    if(nombre2 != "")
    {
        document.querySelector(`#grupo__nombre .form__input-vacio`).classList.remove('form__input-vacio-activo')
    }

    if(email2 != "")
    {
        document.querySelector(`#grupo__email .form__input-vacio`).classList.remove('form__input-vacio-activo')
    }
    if(clave2 != "")
    {
        document.querySelector(`#grupo__clave .form__input-vacio`).classList.remove('form__input-vacio-activo')
    }
    if(confirma2 != "")
    {
        document.querySelector(`#grupo__confirm .form__input-vacio`).classList.remove('form__input-vacio-activo')
    }
}
